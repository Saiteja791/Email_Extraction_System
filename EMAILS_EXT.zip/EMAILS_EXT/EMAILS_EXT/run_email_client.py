from email_client import EmailClient

if __name__ == "__main__":
    client = EmailClient()
    if client.connect():
        emails = client.fetch_unread_emails(max_emails=5)
        for idx, email in enumerate(emails, 1):
            print(f"Email {idx}:")
            print(f"Subject: {email['subject']}")
            print(f"From: {email['sender']}")
            print(f"Date: {email['date']}")
            print(f"Body: {email['body'][:200]}...")  # Print first 200 chars
            print("="*40)
        client.disconnect()
    else:
        print("Failed to connect to email server.") 